record = float(input())
distance = float(input())
time_per_meter = float(input())

delay = distance // 15

atempt = (distance*time_per_meter) + 12.5*delay
diff = abs(record-atempt)
if atempt < record:
    print(f"Yes, he succeeded! The new world record is {atempt:.2f} seconds.")
else:
    print(f"No, he failed! He was {diff:.2f} seconds slower.")