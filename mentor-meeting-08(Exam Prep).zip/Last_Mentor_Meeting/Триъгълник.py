n = int(input())
width = (4*n)+1
height = (2*n)+1
hash = ((2*n)-1)

print("#"*width)
for row in range(1, n+1):
    if row == (n // 2) + 1:
        spaces = ((width-(hash+hash)-(row+row)-3)//2)
        print("." * row + "#" * hash + " " *spaces + "(@)" + " "*spaces+ "#" * hash + "." * row)
    else:
        print("." * row + "#" * hash + " " * (width - ((hash + hash)+ (row + row)))+ "#" * hash + "." * row)
    hash -= 2
for row in range(1, n+1):
    print("."*(n+row)+ "#"*(width-(n+row)*2) + "."*(n+row))
