n = int(input())

for num_1 in range(1, 10):
    for num_2 in range(1, 10):
        for num_3 in range(1, 10):
            for num_4 in range(1, 10):
                if (num_1+num_2) == (num_3+num_4) and n % (num_1+num_2) == 0:
                    print(str(num_1)+str(num_2)+str(num_3)+str(num_4), end=" ")

