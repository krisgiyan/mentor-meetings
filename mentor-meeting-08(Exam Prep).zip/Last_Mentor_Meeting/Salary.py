salary = float(input())
exp = int(input())
syndicate = input()
count = 0

for i in range(1, exp+1):
    salary += salary * 0.06
    if i % 10 == 5:
        salary += 100
    if i % 10 == 0:
        salary += 200

for i in range(1, exp+1):
    if syndicate == "Yes" and (i % 10 != 5 or i % 10 != 0):
        salary = salary * 0.99
if salary >= 5000:
    salary = 5000
    print(f"Current salary: {salary:.2f}")
    print("0 more years to max salary.")
else:
    new_salary = salary

    for i in range(1, 46 - exp):
        new_salary = new_salary + (new_salary * 0.06)
        if i % 10 == 5:
            new_salary += 100
        if i % 10 == 0:
            new_salary += 200
        if syndicate == "Yes" and (i % 10 == 5 or i % 10 == 0):
            new_salary = new_salary - (new_salary / 100)
        if new_salary < 5000:
            count += 1
    print(f"Current salary: {salary:.2f}")
    print(f"{count} more years to max salary.")









