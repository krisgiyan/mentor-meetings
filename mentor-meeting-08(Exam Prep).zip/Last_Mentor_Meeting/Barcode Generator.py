number_1 = int(input())
number_2 = int(input())

start_4 = number_1 % 10
number_1 = number_1 // 10
start_3 = number_1 % 10
number_1 = number_1 // 10
start_2 = number_1 % 10
number_1 = number_1 // 10
start_1 = number_1

end_4 = number_2 % 10
number_2 = number_2 // 10
end_3 = number_2 % 10
number_2 = number_2 // 10
end_2 = number_2 % 10
number_2 = number_2 // 10
end_1 = number_2

for num_1 in range(start_1, end_1+1):
    for num_2 in range(start_2, end_2 + 1):
        for num_3 in range(start_3, end_3 + 1):
            for num_4 in range(start_4, end_4 + 1):
                if num_1 % 2 != 0 and num_2 % 2 != 0 and num_3 % 2 != 0 and num_4 % 2 != 0:
                    print("{}{}{}{}".format(num_1, num_2, num_3, num_4), end=" ")


