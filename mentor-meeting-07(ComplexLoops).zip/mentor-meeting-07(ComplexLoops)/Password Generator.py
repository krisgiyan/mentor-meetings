a = int(input())
b = input().upper()
c = input().lower()
d = int(input())
e = int(input())
f = int(input())
n = int(input())

count = 0

for num_1 in range(1, a+1):
    for letter_1 in range(ord("A"), ord(b)+1):
        letter_1 = chr(letter_1)
        for letter_2 in range(ord("a"), ord(c)+1):
            letter_2 = chr(letter_2)
            for num_2 in range(1, d+1):
                for num_3 in range(1, e+1):
                    for num_4 in range(1, f+1):
                        count += 1
                        if count == n:
                            print(f"{num_1}{letter_1}{letter_2}{num_2}{num_3}{num_4}")
                            exit()
print("No password on this position")