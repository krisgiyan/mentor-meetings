a = int(input())
b = int(input())
max_count = int(input())

count = 0
m = 32
n = 57

for x in range(1, a+1):
    for y in range(1, b+1):
        if count == max_count:
            exit()
        count += 1
        m += 1
        n += 1
        if m > 47:
            m = 33
        if n > 64:
            n = 58
        print(chr(m) + chr(n) + str(x) + str(y) + chr(n) + chr(m), end="|")

