a = int(input())
b = input()
c = input()
d = input()
e = int(input())
n = int(input())

count = 0

for num_1 in range(a, 100):
    if num_1 % 10 == 2:
        for letter_1 in range(ord(b), ord("Z")+1):
            for letter_2 in range(ord(c), ord("z")+1):
                for letter_3 in range(ord(d), ord("Z")+1):
                    for num_2 in range(e, 9, -1):
                        if num_2 % 10 == 5:
                            count += 1
                            if count == n:
                                print(str(num_1) + chr(letter_1) + chr(letter_2) + chr(letter_3) + str(num_2))
                                exit()
