start = int(input())
final = int(input())

for num_1 in range(start, final+1):
    for num_2 in range(start, final + 1):
        for num_3 in range(start, final + 1):
            for num_4 in range(start, final + 1):
                case = num_1+num_4
                if case % 2 != 0:
                    if num_1 > num_4:
                        if (num_2+num_3) % 2 == 0:
                            print(f"{num_1}{num_2}{num_3}{num_4}", end=" ")