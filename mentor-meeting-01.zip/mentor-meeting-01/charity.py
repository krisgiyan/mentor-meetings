days = int(input())
chiefs = int(input())
cakes = int(input())
waffles = int(input())
pancakes = int(input())

cakes_money_PD = cakes * chiefs * 45
waffles_money_PD = waffles * chiefs * 5.80
pancakes_money_PD = pancakes * chiefs * 3.20

money = (cakes_money_PD + waffles_money_PD + pancakes_money_PD) * days

raised_money = money - (money / 8)

print("%.2f" % raised_money)


