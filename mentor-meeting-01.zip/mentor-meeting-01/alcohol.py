whisky_price = float(input())
amount_beer = float(input())
amount_wine = float(input())
amount_rakia = float(input())
amount_whisky = float(input())

rakia_price = whisky_price * 0.5
beer_price = rakia_price - (0.8 * rakia_price)
wine_price = rakia_price - (0.4 * rakia_price)

total_rakia_price = rakia_price * amount_rakia
total_beer_price = beer_price * amount_beer
total_wine_price = amount_wine * wine_price
total_whisky_price = amount_whisky * whisky_price

total_cost = total_rakia_price + \
    total_beer_price + total_whisky_price + total_wine_price

print("%.2f" % total_cost)
