rolls_paper = int(input())
rolls_silk = int(input())
glue = float(input())
discount = int(input())

price_paper = rolls_paper * 5.80
price_silk = rolls_silk * 7.20
price_glue = glue * 1.20

full_price = price_paper + price_silk + price_glue

price_with_discount = full_price - ((full_price * discount)/100)


a = 4.555

print("%.2f" % a)

print("%.3f" % price_with_discount)