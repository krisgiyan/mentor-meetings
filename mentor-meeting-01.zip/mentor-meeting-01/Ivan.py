working_days = int(input())
daily_money = float(input())
dollar = float(input())

money_per_month = working_days * daily_money
money_per_year = (money_per_month * 12) + (money_per_month * 2.5)

taken_money = money_per_year * 0.75

taken_money_leva = taken_money * dollar

final_result = taken_money_leva / 365

print("%.2f" % final_result)