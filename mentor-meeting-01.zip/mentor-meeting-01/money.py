bitcoin = int(input())
cny = float(input())
com = float(input())

bitcoin_value = 1168
cny_value = 0.15 * 1.76

all_bitcoin = bitcoin * bitcoin_value
all_cny = cny * cny_value

all_money = (all_bitcoin + all_cny) / 1.95

money_without_com = all_money - ((all_money * com) / 100)

print("%.2f" % money_without_com)







