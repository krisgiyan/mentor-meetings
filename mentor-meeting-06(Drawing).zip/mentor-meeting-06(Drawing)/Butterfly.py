n = int(input())
width = (n*4)-4

for i in range(1, n-1):
    print("*\\"*i + " "*(width-(4*i)) + "/*"*i)
print("\/"*((n*2)-2))
for i in range(1, (n//2)+1):
    print("<"*((width//2)-3)+ "*|**|*" + ">"*((width//2)-3))
print("/\\"*((n*2)-2))
for i in range(1, n-1,):
    print("*/"*(n-(1+i))+" "*(width-((n-(1+i))*4))+ "\\*"*(n-(1+i)))