n = int(input())
height = (8*n)-8
wight = (2*n) + 1

for i in range(0, n-3):
    print(" "*n + "|")
print(" "*(n-1) + "_|_")
for i in range(0, n-3):
    print(" "*(n-1) + "|-|")
print(" "*(n-2) + "_|-|_")

for i in range(1, n-2):
    print(" "*(n-2) + "|***|")
if n > 3:
    print(" " + "_"*(n-3) + "|***|" + "_"*(n-3))
else:
    print(" |***|")
for i in range(1, (n*4)+1):
    if i == n*4:
        print("_" + "|" * (n - 2) + "---" + "|" * (n - 2) + "_")
    else:
        print(" " + "|" * (n - 2) + "---" + "|" * (n - 2))
for i in range(1, n-1):
    print("|"*wight)



