hole_width = int(input())
hole_lenght = int(input())
painting_side = int(input())
painting_num = int(input())

hole_area = hole_width * hole_lenght
painting_area = painting_side ** 2
all_painting_area = painting_area * painting_num

if hole_area >= all_painting_area:
    diff = hole_area - all_painting_area
    print("The pictures fit in the hole. Hole area is {} bigger than pictures area.".format(diff))
elif all_painting_area > hole_area:
    diff = all_painting_area - hole_area
    print("The pictures don't fit in the hole. Picture area is {} bigger than hole area.".format(diff))

