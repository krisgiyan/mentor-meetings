import math
width = float(input())
lenght = float(input())
height = float(input())
people_height = float(input())

spaceship = width * lenght * height
room = 2 * 2 * (people_height + 0.4)

num_of_people = math.floor(spaceship / room)

if num_of_people < 3:
    print("The spacecraft is too small.")
elif num_of_people > 10:
    print("The spacecraft is too big.")
else:
    print("The spacecraft holds {} astronauts.".format(num_of_people))