import math
par = int(input())
voted_first = int(input())

voted_second = voted_first * 0.8
voted_third = voted_second * 0.9

first_third = voted_first + voted_second + voted_third

half_votes = math.floor(par / 2)

if first_third >= half_votes:
    diff = math.floor(first_third - half_votes)
    print("First three languages have {} votes more".format(diff))
elif half_votes > first_third:
    diff = math.ceil(half_votes - first_third)
    print("First three languages have {} votes less of half votes".format(diff))