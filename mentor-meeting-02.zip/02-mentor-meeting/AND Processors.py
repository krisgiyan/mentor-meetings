target_cpu = int(input())
employers = int(input())
working_days = int(input())

working_hours = employers * working_days * 8
made_cpu = int(working_hours / 3)

if target_cpu > made_cpu:
    losses = "%.2f" % ((target_cpu * 110.10) - (made_cpu * 110.10))
    print("Losses: -> {} BGN".format(losses))
elif made_cpu >= target_cpu:
    profit = "%.2f" % ((made_cpu * 110.10) - (target_cpu * 110.10))
    print("Profit: -> {} BGN".format(profit))

