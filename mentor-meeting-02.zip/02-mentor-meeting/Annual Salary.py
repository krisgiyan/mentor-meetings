exp = int(input())
profile = input()

month_salary = 0

if profile == "C# Developer":
    month_salary = 5400
elif profile == "Java Developer":
    month_salary = 5700
elif profile == "Front-End Web Developer":
    month_salary = 4100
elif profile == "UX / UI Designer":
    month_salary = 3100
elif profile == "Game Designer":
    month_salary = 3600

if exp <= 5:
    month_salary = (month_salary * (100 - 65.8)) / 100

year_salary = "%.2f" % (month_salary * 12)

print("Total earned money: {} BGN".format(year_salary))