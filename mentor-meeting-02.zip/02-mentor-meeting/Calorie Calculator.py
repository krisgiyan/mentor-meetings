import math
gender = input()
weight = float(input())
height = float(input())
age = int(input())
physical_activity = input()

BNM = 0

if gender == "m":
    BNM = 66 + (13.7 * weight) + (5 * height * 100) - (6.8 * age)
elif gender == "f":
    BNM = 655 + (9.6 * weight) + (1.8 * height * 100) - (4.7 * age)

if physical_activity == "sedentary":
    coef = 1.2
    result = math.ceil(BNM * coef)
    print("To maintain your current weight you will need {} calories per day.".format(result))
elif physical_activity == "lightly active":
    coef = 1.375
    result = math.ceil(BNM * coef)
    print("To maintain your current weight you will need {} calories per day.".format(result))
elif physical_activity == "moderately active":
    coef = 1.55
    result = math.ceil(BNM * coef)
    print("To maintain your current weight you will need {} calories per day.".format(result))
elif physical_activity == "very active":
    coef = 1.725
    result = math.ceil(BNM * coef)
    print("To maintain your current weight you will need {} calories per day.".format(result))



