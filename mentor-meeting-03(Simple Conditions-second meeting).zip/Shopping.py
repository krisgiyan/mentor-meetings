import math
budget = float(input())
num_chocos = int(input())
milk = float(input())

num_tangerines = math.floor(num_chocos * 0.65)

chocos_price = num_chocos * 0.65
milk_price = 2.70 * milk
tangerine_price = num_tangerines * 0.2

total_cost = chocos_price + milk_price + tangerine_price

if budget >= total_cost:
    diff = "%.2f" % (budget - total_cost)
    print("You got this, {} money left!".format(diff))
else:
    diff = "%.2f" % (total_cost - budget)
    print("Not enough money, you need {} more!".format(diff))