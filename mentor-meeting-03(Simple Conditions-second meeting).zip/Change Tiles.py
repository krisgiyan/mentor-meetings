import math
money = float(input())
floor_width = float(input())
floor_length = float(input())
triange_side = float(input())
triange_height = float(input())
piece_price = float(input())
worker_money = float(input())

floor_area = floor_length * floor_width

triange_area = (triange_side * triange_height) / 2

num_pieces = math.ceil((floor_area / triange_area) + 5)

total_cost = (num_pieces * piece_price) + worker_money

if money >= total_cost:
    diff = "%.2f" % (money - total_cost)
    print("{} lv left.".format(diff))
else:
    diff = "%.2f" % (total_cost - money)
    print("You'll need {} lv more.".format(diff))