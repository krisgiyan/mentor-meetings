h = int(input())
m = int(input())
flight_time = int(input())

hours = 0
minutes = 0

all_minutes = m + flight_time

minutes_to_hours = all_minutes // 60

minutes_left = all_minutes - (60 * minutes_to_hours)

if all_minutes >= 1:
    hours = h + minutes_to_hours
    minutes = all_minutes - (60 * minutes_to_hours)
else:
    hours = h
    minutes = all_minutes

if hours > 23:
    hours = hours - 24
print("{}h {}m".format(hours, minutes))