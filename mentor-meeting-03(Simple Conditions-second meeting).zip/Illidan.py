num_people = int(input())
damage_1_player = int(input())
life_illidan = int(input())

full_damage = damage_1_player * num_people

if full_damage >= life_illidan:
    diff = full_damage - life_illidan
    print("Illidan has been slain! You defeated him with {} points.".format(diff))
else:
    diff = life_illidan - full_damage
    print("You are not prepared! You need {} more points.".format(diff))