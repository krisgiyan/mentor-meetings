poolV = int(input())
P1 = int(input())
P2 = int(input())
time = float(input())

p1Full = time * P1
p2Full = time * P2

waterInThePool = p1Full + p2Full

if waterInThePool <= poolV:
    waterProcFull = (int)((waterInThePool / poolV) * 100)
    pipe1Proc = (int)((p1Full / waterInThePool) * 100)
    pipe2Proc = (int)((p2Full / waterInThePool) * 100)
    print(f"The pool is {waterProcFull}% full. Pipe 1: {pipe1Proc}%. Pipe 2: {pipe2Proc}%.")
else:
    print("For %.1f hours the pool overflows with %.1f liters." % (time, waterInThePool - poolV))