import math
incomes = float(input())
average_score = float(input())
min_salary = float(input())

social_scholarship = math.floor(min_salary * 0.35)
score_scholarship = math.floor(average_score * 25)

if average_score < 4.5:
    print("You cannot get a scholarship!")

if average_score < 5.5 and average_score > 4.5:
    if incomes < min_salary:
        print("You get a Social scholarship {} BGN".format(social_scholarship))
    else:
        print("You cannot get a scholarship!")
if average_score >= 5.5:
    if social_scholarship > score_scholarship and incomes < min_salary:
        print("You get a Social scholarship {} BGN".format(social_scholarship))
    else:
        print("You get a scholarship for excellent results {} BGN".format(score_scholarship))

