import math
volume_pool = int(input())
debit_pipe_1 = int(input())
debit_pipe_2 = int(input())
hours = float(input())

water_pipe_1 = debit_pipe_1 * hours
water_pipe_2 = debit_pipe_2 * hours

all_water = water_pipe_1 + water_pipe_2

percent_pipe_1 = math.floor((water_pipe_1 / all_water) * 100)
percent_pipe_2 = math.floor((water_pipe_2 / all_water) * 100)

percent_full = math.floor((all_water / volume_pool) * 100)

if all_water > volume_pool:
    diff = "%.2f" % (all_water - volume_pool)
    print("For {} hours the pool overflows with {} liters.".format(hours, diff))
elif volume_pool >= all_water:
    print("The pool is {}% full. Pipe 1: {}%. Pipe 2: {}%.".format(percent_full, percent_pipe_1, percent_pipe_2))






