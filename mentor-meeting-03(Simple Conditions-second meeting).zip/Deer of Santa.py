import math
days_missing = int(input())
left_food = int(input())
first_deer = float(input())
second_deer = float(input())
third_deer = float(input())

first_food = days_missing * first_deer
second_food = days_missing * second_deer
third_food = days_missing * third_deer

total_food = first_food + second_food + third_food

if left_food >= total_food:
    diff = math.floor(left_food - total_food)
    print("{} kilos of food left.".format(diff))
else:
    diff = math.ceil(total_food - left_food)
    print("{} more kilos of food are needed.".format(diff))

