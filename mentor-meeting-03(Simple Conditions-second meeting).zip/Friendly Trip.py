distance = float(input())
hundred_km = int(input())
gas_price = float(input())
budget = int(input())

total_gas = distance * (hundred_km / 100)
total_cost = total_gas * (gas_price)

if budget >= total_cost:
    diff = round((budget - total_cost), 2)
    print("You can take a trip. %.2f money left." % (diff))
else:
    money_per_person = round((budget / 5), 2)
    print("Sorry, you cannot take a trip. Each will receive %.2f money." % (money_per_person))


