stage_one = input()
num_one = int(input())
stage_two = input()
num_two = int(input())
stage_three = input()
num_three = int(input())

online = 0
onsite = 0

if stage_one == "onsite":
    onsite += num_one
elif stage_one == "online":
    online += num_one

if stage_two == "onsite":
    onsite += num_two
elif stage_two == "online":
    online += num_two

if stage_three == "onsite":
    onsite += num_three
elif stage_three == "online":
    online += num_three

if onsite > 600:
    online = (onsite + online) - 600
    onsite = 600

total = online + onsite

print("Online students: {}".format(online))
print("Onsite students: {}".format(onsite))
print("Total students: {}".format(total))
