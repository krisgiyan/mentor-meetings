h = int(input())
x = int(input())
y = int(input())
result = "Outside"
if x >= 0 and x <= h*3 and y == 0:
    result = "Border"
elif y >= 0 and y <= h and x == 0:
    result = "Border"
elif x == h*3 and y >= 0 and y <= h:
    result = "Border"
elif y == h and x >= 0 and x <= h:
    result = "Border"
elif y == h and x >= h*2 and x <= h*3:
    result = "Border"
elif x == h and y >= h and y <= h*4:
    result = "Border"
elif x == h*2 and y >= h and y <= h*4:
    result = "Border"
elif y == h*4 and x >= h and x <= h*2:
    result = "Border"

if y > 0 and y < h and x > 0 and x < h*3:
    result = "Inside"
elif x > h and x < h*2 and y >= h and y < h*4:
    result = "Inside"
print(result)