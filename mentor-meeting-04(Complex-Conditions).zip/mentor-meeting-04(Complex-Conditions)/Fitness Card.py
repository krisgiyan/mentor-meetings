money = float(input())
gender = input()
age = int(input())
sport = input().lower()

sport_price = 0

if gender == "m":
    if sport == "gym":
        sport_price = 42
    elif sport == "boxing":
        sport_price = 41
    elif sport == "yoga":
        sport_price = 45
    elif sport == "zumba":
        sport_price = 34
    elif sport == "dances":
        sport_price = 51
    elif sport == "pilates":
        sport_price = 39
elif gender == "f":
    if sport == "gym":
        sport_price = 35
    elif sport == "boxing":
        sport_price = 37
    elif sport == "yoga":
        sport_price = 42
    elif sport == "zumba":
        sport_price = 31
    elif sport == "dances":
        sport_price = 53
    elif sport == "pilates":
        sport_price = 37

if age <= 19:
    sport_price = sport_price * 0.8

if money >= sport_price:
    print("You purchased a 1 month pass for {}.".format(sport.title()))
else:
    diff = "%.2f" % (sport_price - money)
    print("You don't have enough money! You need ${} more.".format(diff))
