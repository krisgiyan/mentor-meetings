planet = input()
days = int(input())
invalid_days ="Invalid number of days!"
distance = 0

if planet == "Mercury":
    distance = 0.61
    if days < 1 or days > 7:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
elif planet == "Venus":
    distance = 0.28
    if days < 1 or days > 14:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
elif planet == "Mars":
    distance = 0.52
    if days < 1 or days > 20:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
elif planet == "Jupiter":
    distance = 4.2
    if days < 1 or days > 5:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
elif planet == "Saturn":
    distance = 8.52
    if days < 1 or days > 3:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
elif planet == "Uranus":
    distance = 18.21
    if days < 1 or days > 3:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
elif planet == "Neptune":
    distance = 29.09
    if days < 1 or days > 2:
        print(invalid_days)
    else:
        whole_distance = distance * 2
        d_days = whole_distance * 226
        total_days = d_days + days
        print("Distance: {}".format("%.2f" % whole_distance))
        print("Total number of days: {}".format("%.2f" % total_days))
else:
    print("Invalid planet name!")



