planet = input()
days = int(input())

distance = 0

if planet == "Mercury":
    if days > 0 and days < 8:
        distance = 0.61
    else:
        print("Invalid number of days!")

elif planet == "Venus":
    if days > 0 and days < 15:
        distance = 0.28
    else:
        print("Invalid number of days!")

elif planet == "Mars":
    if days > 0 and days < 21:
        distance = 0.52
    else:
        print("Invalid number of days!")
elif planet == "Jupiter":
    if days > 0 and days < 6:
        distance = 4.2
    else:
        print("Invalid number of days!")
elif planet == "Saturn":
    if days > 0 and days < 4:
        distance = 8.52
    else:
        print("Invalid number of days!")
elif planet == "Uranus":
    if days > 0 and days < 4:
        distance = 18.21
    else:
        print("Invalid number of days!")
elif planet == "Neptune":
    if days > 0 and days < 3:
        distance = 29.09
    else:
        print("Invalid number of days!")

else:
    print("Invalid planet name!")

if distance > 0:
    all_distance = distance * 2
    d_days = all_distance * 226
    total_days = d_days + days
    print("Distance: {}".format("%.2f" % (all_distance)))
    print("Total number of days: {}".format("%.2f" % (total_days)))

