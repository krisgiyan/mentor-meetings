num_days = int(input())
total_min = 0
total_distance = 0
for i in range(1, num_days+1):
    runnin_time = int(input())
    runnin_distance = float(input())
    unit = input()
    total_min += runnin_time
    if unit == "m":
        total_distance += runnin_distance / 1000
    else:
        total_distance += runnin_distance

calories = (total_min / 20) * 400

print("He ran %.2fkm for %.0f minutes and burned %.0f calories." % (total_distance, total_min, calories))


