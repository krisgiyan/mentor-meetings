num_courses = int(input())
credits = 0
grade = 0

for i in range(1, num_courses+1):
    inpt = int(input())
    if inpt % 10 == 2:
        credits += 0
        grade += 2
    elif inpt % 10 == 3:
        credits += (inpt // 10) * 0.5
        grade += 3
    elif inpt % 10 == 4:
        credits += (inpt // 10) * 0.7
        grade += 4
    elif inpt % 10 == 5:
        credits += (inpt // 10) * 0.85
        grade += 5
    elif inpt % 10 == 6:
        credits += (inpt // 10)
        grade += 6

average_grade = grade / num_courses

print("%.2f" % credits)
print("%.2f" % average_grade)