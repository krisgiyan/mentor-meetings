num_pairs = int(input())
pair_sum = None
global_diff = 0

for i in range(0, num_pairs):
    num1 = int(input())
    num2 = int(input())
    diff = 0
    if pair_sum != None:
        diff = abs(pair_sum - (num1 + num2))
    pair_sum = (num1 + num2)
    if diff != 0:
        global_diff = diff
    if diff > global_diff:
        global_diff = diff

if global_diff == 0:
    print("Yes, value={}".format(pair_sum))
else:
    print("No, maxdiff={}".format(global_diff))


