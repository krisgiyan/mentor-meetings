import sys
num = int(input())
OddSum = 0
OddMin = sys.maxsize
OddMax = -sys.maxsize
EvenSum = 0
EvenMin = sys.maxsize
EvenMax = -sys.maxsize
for i in range(1, num+1):
    number = float(input())
    if i % 2 == 1:
        OddSum += number
        if OddMin > number:
            OddMin = number
        if OddMax < number:
            OddMax = number
    elif i % 2 == 0:
        EvenSum += number
        if EvenMin > number:
            EvenMin = number
        if EvenMax < number:
            EvenMax = number
if OddMin == sys.maxsize:
    OddMin = "No"
else:
    OddMin = "%g" % OddMin
if OddMax == -sys.maxsize:
    OddMax = "No"
else:
    OddMax = "%g" % OddMax
if EvenMin == sys.maxsize:
    EvenMin = "No"
else:
    EvenMin = "%g" % EvenMin
if EvenMax == -sys.maxsize:
    EvenMax = "No"
else:
    EvenMax = "%g" % EvenMax

print("OddSum=%g," % OddSum)
print("OddMin={},".format(OddMin))
print("OddMax={},".format(OddMax))
print("EvenSum=%g," % EvenSum)
print("EvenMin={},".format(EvenMin))
print("EvenMax={}".format(EvenMax))
