num_item = int(input())
money = int(input())
needed_money = 0
if num_item > 7:
    print("Sorry, you can't carry so many things!")
else:
    for i in range(1, num_item+1):
        gun_type = input()
        if gun_type == "ak47":
            needed_money += 2700
        elif gun_type == "awp":
            needed_money += 4750
        elif gun_type == "sg553":
            needed_money += 3500
        elif gun_type == "grenade":
            needed_money += 300
        elif gun_type == "flash":
            needed_money += 250
        elif gun_type == "glock":
            needed_money += 500
        elif gun_type == "bazooka":
            needed_money += 5600
    if needed_money <= money:
        print("You bought all {} items! Get to work and defeat the bomb!".format(num_item))
    else:
        diff = needed_money - money
        print("Not enough money! You need {} more money.".format(diff))
